(function () {
    'use strict';

    angular.module('app.contracts', []);

})();
