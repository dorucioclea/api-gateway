(function () {
    'use strict';

    angular.module('app.user.profile', []);

})();
