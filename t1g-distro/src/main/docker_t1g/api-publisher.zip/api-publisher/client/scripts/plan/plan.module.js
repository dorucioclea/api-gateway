(function () {
    'use strict';

    angular.module('app.plan', []);

})();
