# astad-config

Depends upon global.__base that needs to point to the root directory.
