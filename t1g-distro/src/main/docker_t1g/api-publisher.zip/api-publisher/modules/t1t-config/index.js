module.exports = require('./lib/config');
