Changelog
===================

### v1.1.2 (02/03/2016)
 - publish to sinopia

### v1.1.0 (07/01/2016)

 - Display objects
 - Add access middleware