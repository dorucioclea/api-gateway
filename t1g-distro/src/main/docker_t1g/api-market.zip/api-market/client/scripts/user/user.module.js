(function () {
    'use strict';

    angular.module('app.user', ['app.user.profile']);

})();
