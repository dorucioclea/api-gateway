;(function(angular) {
    'use strict';

    angular.module('app.ctrl.login', [])
      /// ==== Login Controller
    .controller('LoginCtrl', function($scope, $state) {

    });
    // #end
})(window.angular);
